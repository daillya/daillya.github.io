#ifndef GRAPHE_HPP
#define GRAPHE_HPP

/*
Classe modélisant le graphe. Vous pouvez ajouter des fonctionnalités.
*/

#include "Sommet.h"

class Graphe {
	public:
	Graphe();
	virtual ~Graphe();
	int getNbSommets();
	void ajouteSommet(Sommet* s);
	Sommet* getSommet(int i);

	protected:
	int nbSommets;
	Sommet** sommets;
};

#endif
