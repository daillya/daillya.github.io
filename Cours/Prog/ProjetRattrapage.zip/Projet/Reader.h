#ifndef READER_HPP
#define READER_HPP

/*
Classe permettant de charger un graphe depuis un fichier.
Fonctionne sur les fichiers suivant le format du benchmark DIMACS : http://www.info.univ-angers.fr/pub/porumbel/graphs/
*/

#include "Graphe.h"
#include <iostream>
#include <fstream>
#include <string>

class Reader {
	public:
	Reader();
	Reader(const char* f);
	virtual ~Reader();
	Graphe* lireGraphe();
	
	protected:
	const char* filename;
};

#endif
