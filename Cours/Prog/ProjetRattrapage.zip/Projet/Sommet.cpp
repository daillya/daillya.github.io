#include "Sommet.h"

Sommet::Sommet() { /*TODO*/ }

Sommet::~Sommet() { /*TODO*/ }

int Sommet::getDegre() { /*TODO*/ }

void Sommet::ajouteVoisin(Sommet* s) { /*TODO*/ }

Sommet* Sommet::getVoisin(int i) { /*TODO*/ }
