#ifndef SOMMET_HPP
#define SOMMET_HPP

/*
Classe modélisant un sommet.
*/

#include <stdlib.h>
#include <iostream>

class Sommet {
	public:
	Sommet();
	virtual ~Sommet();
	int getDegre();
	void ajouteVoisin(Sommet* s);
	Sommet* getVoisin(int i);

	protected:
	int degre;
	Sommet** voisins;
};

#endif
