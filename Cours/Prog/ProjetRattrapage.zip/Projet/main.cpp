#include "Reader.h"

int main() {
	Reader r("dsjc250.5.col"); // Remplacez l'argument par le nom du fichier que vous souhaitez charger (pensez à spécifier sa position relative dans l'arborescence de votre système de fichiers).
	Graphe* g = r.lireGraphe(); // Le graphe contenu dans le fichier.
	
	std::cout << "Le graphe a " << g->getNbSommets() << " sommets." << std::endl;
	
	/*
	Ajoutez du code ici pour manipuler le graphe que vous avez chargé.
	*/

	return 0;
}
