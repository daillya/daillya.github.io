#include <iostream>
#include "Roue.h"

Roue::Roue (void) : pression(2.5), marque("Standard") {
}

Roue::Roue (double p, std::string s) : pression(p), marque(s) {
}

Roue::~Roue() {}

void Roue::afficher (void) const {
	std::cout << "La roue de marque " << marque << " a une pression de " << pression << " bars." << std::endl;
}

void Roue::setPression (double p) {
	if (p > 0 && p < 10) {
		pression = p;
	}
}

void Roue::setMarque (std::string s) {
	if (s != "") {
		marque = s;
	}
}

double Roue::getPression (void) const {
	return pression;
}

std::string Roue::getMarque (void) const {
	return marque;
}
