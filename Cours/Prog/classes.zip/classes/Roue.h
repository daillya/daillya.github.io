#ifndef ROUE_H
#define ROUE_H

class Roue {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Roue (void);
		Roue (double p, std::string s);
		~Roue();
		void afficher (void) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		void setPression (double p);
		void setMarque (std::string s);
		double getPression (void) const;
		std::string getMarque (void) const;
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		double pression;
		std::string marque;
};

#endif
