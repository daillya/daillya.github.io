#include <iostream>
#include "Voiture.h"

Voiture::Voiture (void) : kilometrage(0), marque("Standard") {
	for (unsigned int i = 0; i < 4; ++i) {
		roues[i] = Roue();
	}
}

Voiture::Voiture (int km, std::string s, Roue t[4]) : kilometrage(km), marque(s) {
	for (unsigned int i = 0; i < 4; ++i) {
		roues[i] = t[i];
	}
}

Voiture::~Voiture() {}

void Voiture::afficher(void) const {
	std::cout << "La voiture de marque " << getMarque() << " a déjà roulé " << getKilometrage() << "km." << std::endl;
	std::cout << "Ses roues présentent les caractéristiques suivantes :" << std::endl;
	for (unsigned int i = 0; i < 4; ++i) {
		roues[i].afficher();
	}
}
void Voiture::setKilometrage (int km) {
	if (km > 0) {
		kilometrage = km;
	}
}

void Voiture::setMarque (std::string s) {
	if (s == "") {
		marque = s;
	}
}

void Voiture::setRoues (Roue t[4]) {
	for (unsigned int i = 0; i < 4; ++i) {
		roues[i] = t[i];
	}
}

int Voiture::getKilometrage (void) const {
	return kilometrage;
}

std::string Voiture::getMarque (void) const {
	return marque;
}

Roue Voiture::getRoue (int i) const {
	if (i > 0 && i < 4) {
		return roues[i];
	}
	else {
		std::cout << "Vous avez demandé une roue n'existant pas !" << std::endl;
		return Roue();
	}
}
