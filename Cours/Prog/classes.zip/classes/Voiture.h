#ifndef VOITURE_H
#define VOITURE_H

#include "Roue.h"

class Voiture {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Voiture (void); // Constructeur par défaut. Appelé par la ligne : Voiture v;
		Voiture (int km, std::string s, Roue t[4]); // Constructeur surchargé.
		~Voiture(); // Destructeur. Il ne doit jamais être appelé explicitement !
		void afficher (void) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		void setKilometrage (int km);
		void setMarque (std::string s);
		void setRoues (Roue t[4]);
		int getKilometrage (void) const;
		std::string getMarque (void) const;
		Roue getRoue (int i) const;
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		int kilometrage;
		std::string marque;
		Roue roues[4];
};

#endif
