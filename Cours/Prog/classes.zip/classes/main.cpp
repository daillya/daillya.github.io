#include <iostream>
#include "Voiture.h"

int main (void) {

	Roue t[4];
	for (unsigned int i = 0; i < 4; ++i) {
		t[i] = Roue(i+0.5, "Michelin");
	}
	Voiture v(10000, "Renault", t);
	
	v.afficher();

	return 0;
}
