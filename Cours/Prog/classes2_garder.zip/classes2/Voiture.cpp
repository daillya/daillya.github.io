#include <iostream>
#include "Voiture.h"

Voiture::Voiture (void) : Vehicule(), toitOuvrant(false) {
}

Voiture::Voiture (int km, double p, bool b) : Vehicule(km,p), toitOuvrant(b) {
}

Voiture::~Voiture(void) {}

void Voiture::afficher(std::ostream &flux) const {
	flux << "La voiture n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher(flux);
	if (toitOuvrant) flux << "De plus, elle a un toit ouvrant !" << std::endl;
	else flux << "Hélas, elle n'a pas de toit ouvrant..." << std::endl;
}

bool Voiture::getToitOuvrant(void) const {
	return toitOuvrant;
}

void Voiture::setToitOuvrant(bool b) {
	toitOuvrant = b;
}
