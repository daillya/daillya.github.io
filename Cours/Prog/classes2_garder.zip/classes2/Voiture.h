#ifndef VOITURE_H
#define VOITURE_H

#include "Vehicule.h"

class Voiture : public Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Voiture (void);
		Voiture (int km, double p, bool b);
		virtual ~Voiture(void);
		virtual void afficher (std::ostream &flux) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		bool getToitOuvrant(void) const;
		void setToitOuvrant(bool b);
	
	private: // Inaccessible en-dehors de la classe -> Idéal pour les attributs
		bool toitOuvrant;
};

#endif
