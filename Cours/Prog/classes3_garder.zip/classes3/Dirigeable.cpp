#include "Dirigeable.h"

Dirigeable::Dirigeable(void) : Vehicule(), altitude(0) {}

Dirigeable::Dirigeable(int km, double p, int a) : Vehicule(km,p), altitude(a) {}

Dirigeable::Dirigeable(int id, int km, double p, int a) : Vehicule(id,km,p), altitude(a) {}

Dirigeable::Dirigeable(std::string filename) {
	const char* fichier(filename.c_str());
	std::ifstream flux (fichier, std::ios::in);
	if (flux) {
		std::string s;
		flux >> s;
		int km, a, id;
		double p;
		flux >> a;
		flux >> id;
		flux >> km;
		flux >> p;
		setId(id);
		setPrix(p);
		setKilometrage(km);
		setAltitude(a);
		flux.close();
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
}

Dirigeable::~Dirigeable(void) {}

void Dirigeable::afficher (std::ostream &flux) const {
	flux << "Le dirigeable n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher(flux);
	flux << "Il peut voler jusqu'à " << getAltitude() << "km d'altitude." << std::endl;
}

void Dirigeable::sauvegarder (std::string s) const {
	const char* fichier(s.c_str());
	std::ofstream flux (fichier, std::ios::out | std::ios::trunc);
	if (flux) {
		flux << "d" << std::endl;
		flux << getAltitude() << std::endl;
		flux.close();
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
	Vehicule::sauvegarder(s);
}

int Dirigeable::getAltitude(void) const {
	return altitude;
}

void Dirigeable::setAltitude(int a) {
	if (a>=0) altitude=a;
}

bool Dirigeable::estUneVoiture(void) const { return false; }

bool Dirigeable::estUnDirigeable(void) const { return true; }
