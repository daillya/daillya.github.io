#ifndef DIRIGEABLE_H
#define DIRIGEABLE_H

#include "Vehicule.h"

class Dirigeable : public Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Dirigeable (void);
		Dirigeable(int km, double p, int a);
		Dirigeable(int id, int km, double p, int a);
		Dirigeable (std::string filename);
		virtual ~Dirigeable(void);
		virtual void afficher (std::ostream &flux) const;
		virtual void sauvegarder (std::string s) const;
		virtual bool estUneVoiture(void) const;
		virtual bool estUnDirigeable(void) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		int getAltitude(void) const;
		void setAltitude(int a);
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		int altitude;
};

#endif
