#include "Garage.h"

Garage::Garage(void) { listeVehicules = std::vector<Vehicule*>(); }

Garage::Garage(std::string filename) {
	const char* fichier(filename.c_str());
	std::ifstream flux (fichier, std::ios::in);
	if (flux) {
		std::cout << "Loading..." << std::endl;
		int n;
		flux >> n;
		std::string type;
		int id;
		for (unsigned int i = 0; i < n; ++i) {
			flux >> type;
			flux >> id;
			if (type == "v") {
				std::string fichier = "DATA/" + std::to_string(id) + ".txt";
				ajouterVehicule(new Voiture(fichier));
			}
			else {
				if (type == "d") {
					std::string fichier = "DATA/" + std::to_string(id) + ".txt";
					ajouterVehicule(new Dirigeable(fichier));
				}
				else {
					std::cerr << "ERREUR : Véhicule de type inconnu." << std::endl;
				}
			}
		}
		flux.close();
		std::cout << "Done!" << std::endl;
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
}

Garage::~Garage(void) {
	for (unsigned int i = 0; i < getNbVehicules(); ++i) {
		delete getVehicule(i);
	}
}

int Garage::getNbVehicules(void) const {
	return listeVehicules.size();
}

Vehicule* Garage::getVehicule(int i) const {
	if (i >= getNbVehicules() || i < 0) {
		std::cout << "ERREUR Vous essayez d'accéder à un véhicule inexistant." << std::endl;
		return NULL;
	}
	else {
		return listeVehicules.at(i);
	}
}

void Garage::afficher(std::ostream &flux) const {
	if (getNbVehicules() == 0) {
		flux << "Le garage est vide :(" << std::endl;
	}
	else {
		flux << "Le garage contient " << getNbVehicules() << " véhicules." << std::endl;
		for (unsigned int i = 0; i < getNbVehicules(); ++i) {
			getVehicule(i)->afficher(flux);
		}
	}
}

void Garage::sauvegarder (void) const {
	std::string filename = "DATA/garage.txt";
	const char* fichier (filename.c_str());
	std::ofstream flux (fichier, std::ios::out | std::ios::trunc);
	if (flux) {
		flux << getNbVehicules() << std::endl;
		for (unsigned int i = 0; i < getNbVehicules(); ++i) {
			int id = getVehicule(i)->getId();
			std::string filename = "DATA/" + std::to_string(id) + ".txt";
			if (getVehicule(i)->estUneVoiture()) {
				flux << "v " << id << std::endl;
			}
			else {
				if (getVehicule(i)->estUnDirigeable()) {
					flux << "d " << id << std::endl;
				}
				else {
					std::cerr << "ERREUR : Véhicule de type inconnu." << std::endl;
				}
			}
			getVehicule(i)->sauvegarder(filename);
		}
		flux.close();
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
}

void Garage::ajouterVehicule(Vehicule* ptrV) {
	listeVehicules.push_back(ptrV);
}

void Garage::ajouterVoiture(void) {
	int km, toit;
	double prix;
	std::cout << "Quel est son prix ?" << std::endl;
	std::cin >> prix;
	std::cout << "Quel kilométrage ?" << std::endl;
	std::cin >> km;
	std::cout << "A-t-elle un toit ouvrant ? (0 si oui)" << std::endl;
	std::cin >> toit;
	if (toit == 0) ajouterVehicule(new Voiture(km,prix,true));
	else ajouterVehicule(new Voiture(km,prix,false));
}

void Garage::ajouterDirigeable(void) {
	int km, alt;
	double prix;
	std::cout << "Quel est son prix ?" << std::endl;
	std::cin >> prix;
	std::cout << "Quel kilométrage ?" << std::endl;
	std::cin >> km;
	std::cout << "Quelle altitude maximale ?" << std::endl;
	std::cin >> alt;
	ajouterVehicule(new Dirigeable(km,prix,alt));
}

void Garage::gestion() {
	int choix = 0;
	do {
		std::cout << "Gestion du garage !" << std::endl;
		std::cout << "1- Afficher tous les véhicules. 2- Ajouter une voiture. 3- Ajouter un dirigeable. Autre- Quitter" << std::endl;
		std::cin >> choix;
		switch (choix) {
			case 1:
				afficher(std::cout);
				break;
			
			case 2:
				ajouterVoiture();
				break;
			
			case 3:
				ajouterDirigeable();
				break;
			
			default:
				choix = 0;
				break;
		}
	} while (choix != 0);
	sauvegarder();
	std::cout << std::endl << "Merci !" << std::endl;
}

std::ostream& operator<<(std::ostream &flux, Garage const& g) {
	g.afficher(flux);
	return flux;
}
