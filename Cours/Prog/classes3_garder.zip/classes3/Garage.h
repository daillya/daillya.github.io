#ifndef GARAGE_H
#define GARAGE_H

#include <vector>
#include "Voiture.h"
#include "Dirigeable.h"

class Garage {
	public:
		Garage(void);
		Garage(std::string filename);
		~Garage(void);
		void gestion();
		void afficher(std::ostream &flux) const;
		void sauvegarder (void) const;
	
	protected:
		int getNbVehicules(void) const;
		Vehicule* getVehicule(int i) const;
		void ajouterVehicule(Vehicule* ptrV);
		void ajouterVoiture(void);
		void ajouterDirigeable(void);
	
	private:
		std::vector<Vehicule*> listeVehicules;
};

std::ostream& operator<<(std::ostream &flux, Garage const& g);

#endif
