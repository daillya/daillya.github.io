#ifndef VEHICULE_H
#define VEHICULE_H

// perso.liris.cnrs.fr/antoine.dailly/enseignement.html

#include <iostream>
#include <fstream>
#include <string>

class Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Vehicule (void);
		Vehicule (int km, double p);
		Vehicule (int id, int km, double p);
		virtual ~Vehicule(void);
		virtual void afficher (std::ostream &flux) const;
		virtual void sauvegarder (std::string s) const;
		virtual bool estUneVoiture(void) const = 0; // Méthode virtuelle pure : la classe Vehicule devient abstraite, impossible d'instancier des objets Vehicule.
		virtual bool estUnDirigeable(void) const = 0;
		int getId (void) const; // Cet accesseur est public pour être utilisé par Garage. Dans l'idéal, mettez aussi peu d'accesseurs que possible en public.
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		void setKilometrage (int km);
		void setPrix (double p);
		int getKilometrage (void) const;
		double getPrix (void) const;
		void setId (int id);
		void updateCpt (void); // Met à jour le compteur global en fonction de l'identifiant du véhicule
	
	private: // Inaccessible en-dehors de la classe -> Idéal pour les attributs
		int kilometrage;
		double prix;
		int id;
		static int cpt; // Compteur global, génère les identifiants des véhicules
};

std::ostream& operator<<(std::ostream &flux, Vehicule const& v);

#endif
