#include <iostream>
#include "Voiture.h"

Voiture::Voiture (void) : Vehicule(), toitOuvrant(false) {}

Voiture::Voiture (int km, double p, bool b) : Vehicule(km,p), toitOuvrant(b) {}

Voiture::Voiture (int id, int km, double p, bool b) : Vehicule(id,km,p), toitOuvrant(b) {}

Voiture::Voiture (std::string filename) {
	const char* fichier(filename.c_str());
	std::ifstream flux (fichier, std::ios::in);
	if (flux) {
		std::string s;
		flux >> s;
		int km, t, id;
		double p;
		flux >> t;
		flux >> id;
		flux >> km;
		flux >> p;
		bool tt;
		if (t == 0) tt = false;
		else tt = true;
		setId(id);
		setPrix(p);
		setKilometrage(km);
		setToitOuvrant(tt);
		flux.close();
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
}

Voiture::~Voiture(void) {}

void Voiture::afficher(std::ostream &flux) const {
	flux << "La voiture n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher(flux);
	if (toitOuvrant) flux << "De plus, elle a un toit ouvrant !" << std::endl;
	else flux << "Hélas, elle n'a pas de toit ouvrant..." << std::endl;
}

void Voiture::sauvegarder (std::string s) const {
	const char* fichier(s.c_str());
	std::ofstream flux (fichier, std::ios::out | std::ios::trunc);
	if (flux) {
		flux << "v" << std::endl;
		if (getToitOuvrant()) flux << 1 << std::endl;
		else flux << 0 << std::endl;
		flux.close();
	}
	else {
		std::cerr << "ERREUR : Impossible d'ouvrir le fichier." << std::endl;
	}
	Vehicule::sauvegarder(s);
}

bool Voiture::getToitOuvrant(void) const {
	return toitOuvrant;
}

void Voiture::setToitOuvrant(bool b) {
	toitOuvrant = b;
}

bool Voiture::estUneVoiture(void) const { return true; }

bool Voiture::estUnDirigeable(void) const { return false; }
