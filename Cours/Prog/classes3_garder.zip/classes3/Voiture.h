#ifndef VOITURE_H
#define VOITURE_H

#include "Vehicule.h"

class Voiture : public Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Voiture (void);
		Voiture (int km, double p, bool b);
		Voiture (int id, int km, double p, bool b);
		Voiture (std::string filename);
		virtual ~Voiture(void);
		virtual void afficher (std::ostream &flux) const;
		virtual void sauvegarder (std::string s) const;
		virtual bool estUneVoiture(void) const;
		virtual bool estUnDirigeable(void) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		bool getToitOuvrant(void) const;
		void setToitOuvrant(bool b);
	
	private: // Inaccessible en-dehors de la classe -> Idéal pour les attributs
		bool toitOuvrant;
};

#endif
