#include<iostream>
#include<stdlib.h>
#include "Voiture.h"
#include "Dirigeable.h"
#include "Garage.h"

int main(void) {
	//Garage g;
	//g.gestion();
	Garage g("DATA/garage.txt");
	g.gestion();
	//std::cout << g;
	
	return 0;
}
