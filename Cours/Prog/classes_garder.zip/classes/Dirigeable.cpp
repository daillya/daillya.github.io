#include "Dirigeable.h"

Dirigeable::Dirigeable(void) : Vehicule(), altitude(0) {}

Dirigeable::Dirigeable(int km, double p, int a) : Vehicule(km,p), altitude(a) {}

Dirigeable::~Dirigeable(void) {}

void Dirigeable::afficher () const {
	std::cout << "Le dirigeable n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher();
	std::cout << "Il peut voler jusqu'à " << getAltitude() << "km d'altitude." << std::endl;
}

int Dirigeable::getAltitude(void) const {
	return altitude;
}

void Dirigeable::setAltitude(int a) {
	if (a>=0) altitude=a;
}
