#ifndef DIRIGEABLE_H
#define DIRIGEABLE_H

#include "Vehicule.h"

class Dirigeable : public Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Dirigeable (void);
		Dirigeable(int km, double p, int a);
		virtual ~Dirigeable(void);
		virtual void afficher () const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		int getAltitude(void) const;
		void setAltitude(int a);
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		int altitude;
};

#endif
