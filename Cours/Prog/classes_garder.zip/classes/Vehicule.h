#ifndef VEHICULE_H
#define VEHICULE_H

#include <iostream>

class Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Vehicule (void);
		Vehicule (int km, double p);
		virtual ~Vehicule(void);
		virtual void afficher () const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		void setKilometrage (int km);
		void setPrix (double p);
		int getKilometrage (void) const;
		double getPrix (void) const;
		int getId (void) const;
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		int kilometrage;
		double prix;
		int id;
		static int cpt;
};

#endif
