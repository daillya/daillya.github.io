#include <iostream>
#include "Voiture.h"

Voiture::Voiture (void) : Vehicule(), toitOuvrant(false) {
}

Voiture::Voiture (int km, double p, bool b) : Vehicule(km,p), toitOuvrant(b) {
}

Voiture::~Voiture(void) {}

void Voiture::afficher() const {
	std::cout << "La voiture n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher();
	if (toitOuvrant) std::cout << "De plus, elle a un toit ouvrant !" << std::endl;
	else std::cout << "Hélas, elle n'a pas de toit ouvrant..." << std::endl;
}

bool Voiture::getToitOuvrant(void) const {
	return toitOuvrant;
}

void Voiture::setToitOuvrant(bool b) {
	toitOuvrant = b;
}
