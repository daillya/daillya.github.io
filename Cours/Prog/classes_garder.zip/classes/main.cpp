#include<iostream>
#include<stdlib.h>
#include "Voiture.h"
#include "Dirigeable.h"

int main(void) {
	Vehicule** tab = (Vehicule**)malloc(5*sizeof(Vehicule*));
	tab[0] = new Voiture(20000,9999.99,true);
	tab[1] = new Dirigeable(150000,39999.99,800);
	tab[2] = new Dirigeable(172000,59999.99,1000);
	tab[3] = new Voiture(10000,10999.99,true);
	tab[4] = new Voiture(50000,2999.99,false);
	for (unsigned int i = 0; i < 5; ++i)
		tab[i]->afficher();
	for (unsigned int i = 0; i < 5; ++i)
		delete tab[i];
	free(tab);
	return 0;
}
