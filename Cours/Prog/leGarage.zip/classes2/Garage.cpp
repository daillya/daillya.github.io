#include "Garage.h"

Garage::Garage(void) {}

Garage::~Garage(void) {
	for (unsigned int i = 0; i < garage.size(); ++i) {
		delete garage.at(i);
	}
}

void Garage::afficher(std::ostream &flux) const {
	flux << std::endl << "Le garage contient les véhicules suivants :" << std::endl;
	for (std::vector<Vehicule*>::const_iterator it = garage.begin(); it != garage.end(); ++it) {
		flux << **it;
	}
}

void Garage::inflation(int add) {
	for (std::vector<Vehicule*>::iterator it = garage.begin(); it != garage.end(); ++it) {
		(**it)+=add;
	}
}
	
void Garage::ajouterVehicule(Vehicule* ptr) {
	garage.push_back(ptr);
}

Vehicule* Garage::getVehicule(int i) const {
	if (i < garage.size())
		return garage.at(i);
}

std::ostream& operator<<(std::ostream &flux, Garage const& g) {
	g.afficher(flux);
    return flux;
}
