#ifndef GARAGE_H
#define GARAGE_H

#include <vector>
#include "Vehicule.h"

class Garage {
	public:
		Garage(void);
		~Garage(void);
		void afficher(std::ostream &flux) const;
		void ajouterVehicule(Vehicule* ptr);
		void inflation(int add);
	
	protected:
		Vehicule* getVehicule(int i) const;
	
	private:
		std::vector<Vehicule*> garage;
};

std::ostream& operator<<(std::ostream &flux, Garage const& g);

#endif
