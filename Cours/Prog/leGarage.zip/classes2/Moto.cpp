#include "Moto.h"

Moto::Moto(void) : Vehicule() {}
Moto::Moto (int km, double p) : Vehicule(km,p) {}

Moto::~Moto(void) {}

void Moto::afficher(std::ostream &flux) const {
	flux << "La moto n°" << getId() << " a les caractéristiques suivantes :" << std::endl;
	Vehicule::afficher(flux);
}

int Moto::nbRoues(void) const {
	return 2;
}
