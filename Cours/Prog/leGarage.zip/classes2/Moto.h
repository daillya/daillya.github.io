#ifndef MOTO_H
#define MOTO_H

#include "Vehicule.h"

class Moto : public Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Moto (void);
		Moto (int km, double p);
		virtual ~Moto(void);
		virtual void afficher (std::ostream &flux) const;
		virtual int nbRoues(void) const;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
};

#endif
