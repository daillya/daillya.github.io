#include "Vehicule.h"

int Vehicule::cpt = 0;

Vehicule::Vehicule (void) : kilometrage(0), prix(0), id(cpt) { ++cpt; }

Vehicule::Vehicule (int km, double p) : kilometrage(km), prix(p), id(cpt) { ++cpt; }

Vehicule::~Vehicule(void) {}

void Vehicule::afficher (std::ostream &flux) const {
	flux << "Kilometrage : " << getKilometrage() << "km." << std::endl;
	flux << "Prix : " << getPrix() << " euros." << std::endl;
}

Vehicule& Vehicule::operator+=(int add) {
	prix += add;
	return *this;
}

void Vehicule::setKilometrage (int km) {
	if (km>=0) kilometrage=km;
}

void Vehicule::setPrix (double p) {
	if (p>=0) prix=p;
}

int Vehicule::getKilometrage (void) const {
	return kilometrage;
}

double Vehicule::getPrix (void) const {
	return prix;
}

int Vehicule::getId (void) const {
	return id;
}

std::ostream& operator<<(std::ostream &flux, Vehicule const& v) {
	v.afficher(flux);
    return flux;
}
