#ifndef VEHICULE_H
#define VEHICULE_H

#include <iostream>

class Vehicule {
	public: // Accessible en-dehors de la classe -> Idéal pour les méthodes
		Vehicule (void);
		Vehicule (int km, double p);
		virtual ~Vehicule(void);
		virtual void afficher (std::ostream &flux) const;
		Vehicule& operator+=(int add);
		virtual int nbRoues(void) const = 0;
	
	protected: // Accessible uniquement par les classes-filles -> Idéal pour les accesseurs
		void setKilometrage (int km);
		void setPrix (double p);
		int getKilometrage (void) const;
		double getPrix (void) const;
		int getId (void) const;
	
	private: // Innaccessible en-dehors de la classe -> Idéal pour les attributs
		int kilometrage;
		double prix;
		int id;
		static int cpt;
};

std::ostream& operator<<(std::ostream &flux, Vehicule const& v);

#endif
