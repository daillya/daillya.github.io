#include <iostream>
#include "Garage.h"
#include "Moto.h"
#include "Voiture.h"
#include "Dirigeable.h"

/*
Les fichiers sont disponibles sur
*/

int main (void) {

	Garage g;
	int cond = 0;
	do {
		std::cout << "0- Quitter\n1- Ajouter une voiture\n2- Ajouter une moto\n3- Ajouter un dirigeable\n4- Afficher le garage\n5- Augmenter tous les prix d'un coup !" << std::endl;
		std::cin >> cond;
		int km;
		double p;
		int t;
		
		switch(cond) {
			case 0: break;
			case 1:
				std::cout << "Kilométrage ? "; std::cin >> km;
				std::cout << "Prix ? "; std::cin >> p;
				std::cout << "Toit ouvrant (0 si non, 1 si oui) ? "; std::cin >> t;
				g.ajouterVehicule(new Voiture(km,p,t));
				break;
			case 2:
				std::cout << "Kilométrage ? "; std::cin >> km;
				std::cout << "Prix ? "; std::cin >> p;
				g.ajouterVehicule(new Moto(km,p));
				break;
			case 3:
				std::cout << "Kilométrage ? "; std::cin >> km;
				std::cout << "Prix ? "; std::cin >> p;
				std::cout << "Altitude max ? "; std::cin >> t;
				g.ajouterVehicule(new Dirigeable(km,p,t));
				break;
			case 4:
				std::cout << g << std::endl;
				break;
			case 5:
				std::cout << "De combien ? "; std::cin >> t;
				g.inflation(t);
				break;
			default: break;
			
		}
	
	} while(cond);

	return 0;
}
